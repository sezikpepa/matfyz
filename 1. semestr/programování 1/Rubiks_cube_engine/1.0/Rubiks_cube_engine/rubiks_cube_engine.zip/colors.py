import pygame

white = pygame.Color("#ffffff")
yellow = pygame.Color("#ffd500")
blue = pygame.Color("#0046ad")
green = pygame.Color("#009b48")
red = pygame.Color("#b71234")
orange = pygame.Color("#ff5800")
black = pygame.Color("#000000")
grey = pygame.Color("#454340")

lime = pygame.Color("#00ff1a")
bage = pygame.Color("#a67605")
tyrkis = pygame.Color("#10e8e1")
violet = pygame.Color("#a809ad")
pink = pygame.Color("#d9048e")
dark_green = pygame.Color("#007508")
