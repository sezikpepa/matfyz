import pygame

#TRANSLATES PYGAME SINGNALS TO STRING REPRESENTATION

keyboard_press_translator: dict = {pygame.K_x: "x",                                   
                                    pygame.K_y: "y",                                   
                                    pygame.K_z: "z",                                   
                                    pygame.K_f: "f",                                   
                                    pygame.K_d: "d",                                  
                                    pygame.K_r: "r",                                   
                                    pygame.K_l: "l",                                   
                                    pygame.K_u: "u",                                 
                                    pygame.K_b: "b"}
                                    


