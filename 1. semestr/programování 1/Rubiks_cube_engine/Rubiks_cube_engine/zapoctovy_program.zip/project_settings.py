
#SETTINGS

window_width = 1920
window_height = 1080

scale = 50
net_scale = int(0.6 * scale)
speed = 100
shift = 1

net_x = 200
net_y = 120

fps = 60


cube_position = [window_width // 2, window_height // 2]

window_caption = "RUBIKS CUBE ENGINE"